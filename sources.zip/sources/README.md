Input source: https://www.cryptocompare.com/
API documentation: https://www.cryptocompare.com/api/#-api-data-price-
Example API call: 
https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=BTC,USD,EUR
https://min-api.cryptocompare.com/data/pricemulti?fsyms=ETH,DASH,LTC,BTC&tsyms=USD

User Story:
As an end user I would like to track volatility of a cryptocurrencys pair (max and min ratio values).
Technical implementation details:
•    All currency ticker symbols (name abbreviations) supported by the application should be configurable via a property file.
•    There should be a verticle that reads dollar rates for all specified crypto-currencies on schedule (e.g. every 5 seconds).
•    Every rate reading should go to the event bus (as a separate event for each currency).
•    There should be a verticle per currency pair 
•    Create a REST endpoint to dynamically add new currency pair to track, i.e. register a new verticle that processes 
     corresponding rates from event bus in order to calculate min and max rate values.
     Both currencies in such pair are always from the list provided in configuration file.
•    Create a REST endpoint to get current max and min rates for a currency pair.

Example of configuration properties file:
currencies=ETH,DASH,LTC,BTC

Example of request that reads current dollar rates respondingly:
https://min-api.cryptocompare.com/data/pricemultifull?fsyms=ETH,DASH,LTC,BTC&tsyms=USD

Example of the POST REST endpoint request/response, ETH/DASH pair:
Request:
POST /cryptos/
{
    "ccy1": "ETH",
    "ccy2": "DASH"
}
Response:
201 OK


Example of the GET REST endpoint request/response, ETH/DASH pair:
Request:
GET /cryptos/ETH/DASH
Response:
{
    "ratio": 1.345
}

