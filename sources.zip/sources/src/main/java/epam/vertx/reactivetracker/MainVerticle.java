package epam.vertx.reactivetracker;

import java.util.Set;

import epam.vertx.reactivetracker.domain.utils.CurrencyUtils;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

public class MainVerticle extends AbstractVerticle {

    private static final Logger logger = LoggerFactory.getLogger(MainVerticle.class);

	Set<String> allSymbols;

	@Override
	public void start(Future<Void> fut) {
		
		JsonArray currencies = config().getJsonArray("currencies");
		allSymbols = CurrencyUtils.getSymbols(currencies);

		vertx.deployVerticle(ServerVerticle.class.getName(), new DeploymentOptions().setConfig(config()));
		vertx.deployVerticle(new DollarRatesReader(allSymbols, config().getInteger("rate.request.interval")));

	}
	

}
