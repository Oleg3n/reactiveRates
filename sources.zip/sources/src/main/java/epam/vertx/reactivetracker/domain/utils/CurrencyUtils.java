package epam.vertx.reactivetracker.domain.utils;

import java.util.HashSet;
import java.util.Set;

import epam.vertx.reactivetracker.domain.Pair;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;

public class CurrencyUtils {
	
	private static final String RATE_REQUEST_EVENT_SUFFIX = "_rate";

	private CurrencyUtils() {
		
	}
	
	public static Set<String> getSymbols(JsonArray currencies) {
		Set<String> resultSet = new HashSet<>();

		for (Object c : currencies) {
			JsonObject currency = (JsonObject) c;
			String symbol = currency.getString("symbol");
			resultSet.add(symbol);
		}
		return resultSet;
	}

	public static String getRateRequestEventAddress(Pair pair) {
		return pair.toString() + RATE_REQUEST_EVENT_SUFFIX;
	}

	public static String getRateRequestEventAddress(String pairString) {
		return pairString + RATE_REQUEST_EVENT_SUFFIX;
	}

	public static String getNewRateEventName(Pair pair) {
		return pair.toString();
	}

}
