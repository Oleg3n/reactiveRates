package epam.vertx.reactivetracker.domain;

import java.util.HashMap;
import java.util.Map;

public class RatesResponse extends HashMap<String, Map<String, Float>> {
	

}
