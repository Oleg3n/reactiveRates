package epam.vertx.reactivetracker;

import epam.vertx.reactivetracker.domain.Pair;
import epam.vertx.reactivetracker.domain.RateResponse;
import epam.vertx.reactivetracker.domain.utils.CurrencyUtils;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.Json;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

public class CurrencyPairVerticle extends AbstractVerticle {

	private static final Logger logger = LoggerFactory.getLogger(CurrencyPairVerticle.class);

	private Float minValue = 0f;
	private Float maxValue = 0f;
	private Float curValue = 0f;

	private Pair pair;

	public CurrencyPairVerticle(Pair pair) {
		this.pair = pair;
	}

	@Override
	public void start(Future<Void> fut) {
		logger.info("CurrencyPairVerticle is consumer for " + pair);

		vertx.eventBus().consumer(pair.toString(), message -> {
			logger.info("from eventBus: '" + CurrencyUtils.getNewRateEventName(pair) + "' new rate = " + message.body());
			Float value = (Float) message.body();
			if (value.compareTo(maxValue) > 0)
				maxValue = value;
			if (value.compareTo(minValue) < 0)
				minValue = value;
			curValue = value;
		});

		vertx.eventBus().consumer(CurrencyUtils.getRateRequestEventAddress(pair), message -> {
			logger.info("from eventBus: received RATE request " + message.body());
			message.reply(Json.encodePrettily(new RateResponse(curValue)));
		});
	}

}
