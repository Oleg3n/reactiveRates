package epam.vertx.reactivetracker.domain;

public class Pair {
	
	private String ccy1;
	private String ccy2;

	public Pair(String ccy1, String ccy2) {
		this.ccy1 = ccy1;
		this.ccy2 = ccy2;
	}

	@Override
	public String toString() {
		return ccy1 + "/" + ccy2;
	}

	public String getCcy1() {
		return ccy1;
	}

	public void setCcy1(String ccy1) {
		this.ccy1 = ccy1;
	}

	public String getCcy2() {
		return ccy2;
	}

	public void setCcy2(String ccy2) {
		this.ccy2 = ccy2;
	}
	

}
