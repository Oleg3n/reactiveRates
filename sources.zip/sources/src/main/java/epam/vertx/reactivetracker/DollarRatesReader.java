package epam.vertx.reactivetracker;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import epam.vertx.reactivetracker.domain.Pair;
import epam.vertx.reactivetracker.domain.RatesResponse;
import epam.vertx.reactivetracker.domain.utils.CurrencyUtils;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpClientResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

public class DollarRatesReader extends AbstractVerticle {
	
    private static final Logger logger = LoggerFactory.getLogger(DollarRatesReader.class);
	
    public static final String 	REQUEST_ADDRESS = "min-api.cryptocompare.com";
    public static final int 	REQUEST_PORT 	= 443;
	public static final String 	USD_SYMBOL 		= "USD";
	private static final String REQUEST_URI_TEMPLATE = "/data/pricemulti?fsyms=[symbols]&tsyms=USD";
	
	int interval = 5000;
	String requestUri;
	Set<String> allSymbols;;
	long timerID;
	HttpClient httpsClient;
	
	public DollarRatesReader(Set<String> allSymbols, int interval) {
		this.allSymbols = allSymbols;
		this.interval = interval;
	}

	@Override
	public void start(Future<Void> fut) {
//		System.setProperty("vertx.logger-delegate-factory-class-name", " io.vertx.core.logging.Log4jLogDelegateFactory"); // Default logger
		requestUri = buildSymbolsString();
		HttpClientOptions options = new HttpClientOptions().setSsl(true).setTrustAll(true);
		httpsClient = vertx.createHttpClient(options);
		
		timerID = vertx.setPeriodic(interval, new Handler<Long>() {
			@Override
			public void handle(Long aLong) {
				readRates();
			}

		});

	}
	
	private void readRates() {
		logger.debug(REQUEST_ADDRESS + ":" + REQUEST_PORT + requestUri);
		httpsClient.getNow(REQUEST_PORT, REQUEST_ADDRESS, requestUri, new Handler<HttpClientResponse>() {
		    @Override
		    public void handle(HttpClientResponse httpClientResponse) {
		        httpClientResponse.bodyHandler(new Handler<Buffer>() {
		            @Override
		            public void handle(Buffer buffer) {
		            	logger.debug("Response size(" + buffer.length() + "): ");
		                logger.info("New Rates recieved: " + buffer.getString(0, buffer.length()));
		                RatesResponse ratesResponse = bufferToObject(buffer);
		                publishResponse(ratesResponse);
		            }
		        });
		    }
		});	
	}
	
	private void publishResponse(RatesResponse ratesResponseMap) {
		Map<String, Float> values = new HashMap<>(); 
		for(Entry<String, Map<String, Float>> ratesMap : ratesResponseMap.entrySet()) {
			Float rate = ratesMap.getValue().get(USD_SYMBOL);
			for(Entry<String, Float> v : values.entrySet()) {
				Pair pair1 = new Pair( ratesMap.getKey(), v.getKey());
				Pair pair2 = new Pair( v.getKey(), ratesMap.getKey());
				logger.debug("to EventBus: '" + pair1 + "' value = " + rate/v.getValue());
				vertx.eventBus().publish(CurrencyUtils.getNewRateEventName(pair1), rate/v.getValue());
				logger.debug("to EventBus: '" + pair2.toString() + "' value = " + v.getValue()/rate);
				vertx.eventBus().publish(CurrencyUtils.getNewRateEventName(pair2), v.getValue()/rate);
			}
			values.put(ratesMap.getKey(), rate);
		}
	}

	private RatesResponse bufferToObject(Buffer buffer) {
		JsonObject jsonObject = buffer.toJsonObject();
		return jsonObject.mapTo(RatesResponse.class);
	}

	private String buildSymbolsString() {
		return REQUEST_URI_TEMPLATE.replace("[symbols]", StringUtils.join(allSymbols, ','));
	}

}
