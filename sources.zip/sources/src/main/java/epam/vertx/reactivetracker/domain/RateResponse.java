package epam.vertx.reactivetracker.domain;

public class RateResponse {

	private Float ratio;
	
	public RateResponse(Float ratio) {
		this.ratio = ratio;
	}

	public Float getRatio() {
		return ratio;
	}

	public void setRatio(Float ratio) {
		this.ratio = ratio;
	}
	
}
