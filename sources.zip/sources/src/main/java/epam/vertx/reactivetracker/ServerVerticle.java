package epam.vertx.reactivetracker;

import epam.vertx.reactivetracker.domain.Pair;
import epam.vertx.reactivetracker.domain.utils.CurrencyUtils;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

public class ServerVerticle extends AbstractVerticle {

    private static final Logger logger = LoggerFactory.getLogger(ServerVerticle.class);
    
    public static final String BASE_URI = "/cryptos/";

	private HttpServer httpServer = null;

	@Override
	public void start(Future<Void> fut) {
		vertx.createHttpServer()
                .requestHandler(httpRequest -> handleHttpRequest(httpRequest) )
                .listen(config().getInteger("http.port", 8080), result -> {
	          if (result.succeeded()) {
	              fut.complete();
	            } else {
	              fut.fail(result.cause());
	            }
	          });

	}
	
	private void handleHttpRequest(final HttpServerRequest request) {
        logger.info(" ==============  incoming request!");

        Buffer fullRequestBody = Buffer.buffer();
        if(request.method() == HttpMethod.POST){

            request.handler(new Handler<Buffer>() {
                @Override
                public void handle(Buffer buffer) {
                    fullRequestBody.appendBuffer(buffer);
                }
            });

            request.endHandler(new Handler<Void>() {
				@Override
				public void handle(Void arg0) {
					if(request.uri().equals(BASE_URI)) {
						addPairResponse(request, fullRequestBody);
					}
				}

            });
        } else if(request.method() == HttpMethod.GET){
        	if(request.uri().startsWith(BASE_URI)) {
        		rateResponse(request);
        	}
        }
	}

	private void addPairResponse(final HttpServerRequest request, Buffer fullRequestBody) {
		JsonObject jsonObject = fullRequestBody.toJsonObject();
		String ccy1 = jsonObject.getString("ccy1");
		String ccy2 = jsonObject.getString("ccy2");
//		vertx.deployVerticle(new CurrencyPairVerticle(new Pair(ccy1, ccy2)));
		Pair pair = new Pair(ccy1, ccy2);
		vertx.deployVerticle(new CurrencyPairVerticle(pair), 
				response -> {
		            if (response.succeeded()) {
		            	request.response().setStatusCode(201).end();
		            } else {
		                logger.error("Can't add pair " + pair.toString(), response.cause());
		                request.response().setStatusCode(500).end(pair.toString() + " " + response.cause().getMessage());
		            }
		        });
		HttpServerResponse response = request.response();
		response.setStatusCode(201);
		response.end();
	}

	private void rateResponse(HttpServerRequest request) {
		logger.info("HTTPServer GET request : " + request.uri());
		String pairString = request.uri().replaceFirst("/cryptos/", "");
        vertx.eventBus().send(CurrencyUtils.getRateRequestEventAddress(pairString),
        		pairString, response -> {
            if (response.succeeded()) {
            	request.response().end(response.result().body().toString());
            } else {
                logger.error("Can't send message to CurrencyPair service", response.cause());
                request.response().setStatusCode(500).end(response.cause().getMessage());
            }
        });
	}

}
