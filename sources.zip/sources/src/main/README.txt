Put any Java or Groovy classes used in your module in the java or groovy directories.

Put any other resources that you want included in your module in the resources directory, this includes any
JavaScript, Ruby, Python, Groovy or CoffeeScript scripts or any other stuff you want in your module.

The mod.json file also goes in the resources directory so it's copied over too.